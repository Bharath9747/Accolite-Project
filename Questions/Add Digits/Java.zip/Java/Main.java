public class Main {
    public static int addDigits(int num) {
        //Write Code here
		
    }
	public static void main(String ar[])
	{
		System.out.print(addDigits(Integer.parseInt(ar[0])));
	}
}