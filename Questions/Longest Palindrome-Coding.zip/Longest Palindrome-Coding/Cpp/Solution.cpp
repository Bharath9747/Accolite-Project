#include <bits/stdc++.h>
using namespace std;
int longestPalindrome(string s) {
	//Write Code Here
}
int main()
{
	string s;
	cin>>s;
	cout<<longestPalindrome(s);
}