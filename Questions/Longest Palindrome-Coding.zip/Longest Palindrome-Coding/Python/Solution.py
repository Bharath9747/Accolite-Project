def longestPalindrome(s: str) -> int:
    #Write Code here    

print(longestPalindrome(input()))