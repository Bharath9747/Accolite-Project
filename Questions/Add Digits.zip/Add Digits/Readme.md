Given an integer num, repeatedly add all its digits until the result has only one digit, and return it.

Example 1:

38
2

Explaination : 
	3+8=11
	1+1=2
	Therefore 2 is the final answer.

Example 2:

123
6