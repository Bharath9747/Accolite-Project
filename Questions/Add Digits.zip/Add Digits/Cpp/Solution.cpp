#include <bits/stdc++.h>
using namespace std;
int addDigits(int num) {
	//Write Code here
}
int main()
{
	int n;
	cin>>n;
	cout<<addDigits(n);
}