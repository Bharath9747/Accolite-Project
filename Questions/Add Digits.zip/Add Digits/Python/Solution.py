def addDigits(num: int) -> int:
    #Write Code here    

print(addDigits(int(input())))