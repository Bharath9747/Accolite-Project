Given a string s which consists of lowercase or uppercase letters, return the length of the longest palindrome that can be built with those letters. Letters are case sensitive, for example, "Aa" is not considered a palindrome here.

Example 1:

aba
3

Explaination : 
	aba is a palindrome. Therefore the longest palindrome length is 3

Example 2:

racecar
7