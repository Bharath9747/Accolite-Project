public class Solution {
    public static int longestPalindrome(String s) {
     //Write COde here
    }
	public static void main(String ar[])
	{
		System.out.println(longestPalindrome(ar[0]));
	}
}